"""Code pulled from future python versions, here for compatibility"""

from collections import MutableMapping, KeysView, ValuesView, ItemsView, OrderedDict
from functools import total_ordering


